## Traditional Rule-Based Chatbot Using Microsoft Bot Framework

### Project Overview

The project demonstrates the development of a traditional rule-based chatbot using Python and the Microsoft Bot Framework. The chatbot responds to user requests that are pre-defined; it does not use a large language model. This implementation includes environment setup, dependency installation, chatbot run and local testing via Bot Framework Emulator. The project is a stepping stone to comprehend conversational application development and offers chances for future enhancements with cloud-based integration of AI.

### Environment Configuration

Anaconda environment is used to isolate the project dependencies and ensures compatibility as the project is developed. Python 3.8.2 is chosen due to its support for libraries for Microsoft Bot Framework used by the application. After environment activation all other project dependencies can be installed before the development and testing of the chatbot.

conda create --name MSAI631_MBF python=3.8.2

### Dependency Installation

The chatbot uses multiple packages of python as indicated in the requirements file. The application requires installation of these dependencies for it to run and to make sure that all the components required by Bot Framework are available to the application. Once successfully installed, the chatbot can be launched and tested locally.

pip install -r requirements.txt

### Bot Framework Emulator Setup

The Microsoft Bot Framework Emulator evaluates the functionality of your chatbot without running it in a cloud platform. The emulator offers an easy-to-use interface to send requests, receive responses and understand the chatbot's behaviour. Local testing makes it easier to debug and find problems with implementing the program during development.

### Launching the Chatbot

Once the environment is set up and all necessary libraries are installed, the chatbot application can be run from the project directory. The application starts the web service, and allows the Chatbot to process incoming requests from the Bot Framework Emulator.
python app.py

### Connecting the Emulator

The chatbot connects with the Bot Framework Emulator using the API endpoint it has been configured with. By choosing Open Bot in the emulator and typing the following endpoint, it gets in touch with a chatbot application running locally.
http://localhost:3978/api/messages
After establishing the connection, the responses of the chatbots can be compared with interactive chats.

### Functional Testing

The Bot Framework Emulator sends different messages through the bot to validate the functionality of the chatbot. Every request is handled by following a set of rules for the conversation and the related response is shown in the conversation window. Emulator logs are also helpful to log requests, responses and application behaviour during testing.

### Development Experience

Some implementation problems were faced while implementing the project, especially in setting up the development environment and addressing dependency compatibility issues. The recommended version of Python was used and required packages were reinstalled as necessary to overcome these difficulties. To enable the chatbot to communicate with the emulator, an additional step of troubleshooting was necessary, which involved setting up the right `/api/messages` endpoint.

### Key Outcomes

The project offered hands-on experience in creating conversational applications with the Microsoft Bot Framework. The setup of isolated environments, dependency management, customization of chatbots, and local testing helped gain insight into the architecture of chatbots. Through continuous testing and incremental improvements, the need for structured development practices in the creation of reliable conversational systems was observed.

### Summary

The project has been accomplished and the result is a classical rule-based chatbot that can give answers to predefined user requests. All of the application was developed, run and tested in a local environment using the Microsoft Bot Framework Emulator. A modular design enables future expansion with additional conversational functionalities, cloud deployment, and advanced AI services, but still ensures the scalable architecture.