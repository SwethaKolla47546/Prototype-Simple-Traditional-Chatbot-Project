# The chatbot application was configured by loading the required settings. 
# A cloud adapter was built that receives messages, and an exception handler was added to handle any unanticipated run-time exceptions. 
# A web application was then started to expose the Bot Framework messaging endpoint.

# Importing libraries for system operations and exception tracking
import sys
import traceback
from datetime import datetime
from http import HTTPStatus

# Importing libraries required for creating the web service
from aiohttp import web
from aiohttp.web import Request, Response, json_response

# Importing Bot Framework components
from botbuilder.core import TurnContext
from botbuilder.core.integration import aiohttp_error_middleware
from botbuilder.integration.aiohttp import (
    CloudAdapter,
    ConfigurationBotFrameworkAuthentication,
)
from botbuilder.schema import Activity, ActivityTypes

# Importing chatbot implementation and configuration
from bots.echo_bot import EchoBot
from config import DefaultConfig

# Loading application configuration values
BOT_SETTINGS = DefaultConfig()

# Creating cloud communication adapter
CHAT_ADAPTER = CloudAdapter(
    ConfigurationBotFrameworkAuthentication(BOT_SETTINGS)
)


# Managing runtime exceptions during conversation processing
async def report_error(turn: TurnContext, exception: Exception):

    # Printing exception details for debugging
    print(f"\n[Bot Exception] {exception}", file=sys.stderr)
    traceback.print_exc()

    # Sending notification messages to the user
    await turn.send_activity(
        "An unexpected error occurred while processing the request."
    )

    await turn.send_activity(
        "Please review the application code before continuing."
    )

    # Sending diagnostic trace information in Emulator
    if turn.activity.channel_id == "emulator":

        emulator_trace = Activity(
            label="RuntimeException",
            name="Conversation Trace",
            timestamp=datetime.utcnow(),
            type=ActivityTypes.trace,
            value=str(exception),
            value_type="https://www.botframework.com/schemas/error",
        )

        await turn.send_activity(emulator_trace)


# Registering the custom error handler
CHAT_ADAPTER.on_turn_error = report_error

# Creating chatbot object
CHAT_ENGINE = EchoBot()


# Receiving requests from Bot Framework
async def process_activity(request: Request) -> Response:

    response = await CHAT_ADAPTER.process(request, CHAT_ENGINE)

    return response


# Creating web application instance
BOT_APPLICATION = web.Application(
    middlewares=[aiohttp_error_middleware]
)

# Registering API endpoint
BOT_APPLICATION.router.add_post(
    "/api/messages",
    process_activity,
)


# Starting chatbot server
if __name__ == "__main__":

    try:

        web.run_app(
            BOT_APPLICATION,
            host="localhost",
            port=BOT_SETTINGS.PORT,
        )

    except Exception as runtime_exception:

        raise runtime_exception